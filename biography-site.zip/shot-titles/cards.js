(() => {
  const directory = '/shot-titles/';
  const width = 1080;
  const height = 1920;
  const titleTop = 1424;
  const oldLabel = '.story-shot-title, .yam-shot-label';
  let renderer;

  function loadImage(url) {
    const image = new Image();
    if (new URL(url, location.href).origin !== location.origin) image.crossOrigin = 'anonymous';
    image.src = url;
    return image.decode().then(() => image);
  }

  function loadRenderer() {
    renderer ??= Promise.all([
      loadImage(directory + 'frame-edge.webp'),
      ...[['ShotName', 'names'], ['ShotDate', 'dates'], ['ShotEvent', 'events']].map(async ([family, file]) => {
        const face = await new FontFace(family, `url(${directory}${file}.woff2)`).load();
        document.fonts.add(face);
      })
    ]).catch(error => {
      renderer = undefined;
      throw error;
    });
    return renderer;
  }

  function canvasOf(height) {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    return canvas;
  }

  function centeredLine(context, text, y, family, size, spacing, maxWidth, color, outline = false) {
    const glyphs = [...text];
    const letters = Math.max(0, glyphs.length - 1);
    context.font = `${size}px ${family}`;
    const advances = glyphs.map(glyph => context.measureText(glyph).width);
    const total = advances.reduce((sum, value) => sum + value, spacing * letters);
    const scale = Math.min(1, maxWidth / total);
    context.save();
    context.translate(width / 2, y - titleTop);
    context.scale(scale, scale);
    context.fillStyle = color;
    context.strokeStyle = '#d8ad70';
    context.lineWidth = .7;
    let x = -total / 2;
    glyphs.forEach((glyph, index) => {
      if (outline) context.strokeText(glyph, x, 0);
      context.fillText(glyph, x, 0);
      x += advances[index] + spacing;
    });
    context.restore();
  }

  async function paintTitle(canvas, name, date, event) {
    const [frame] = await loadRenderer();
    const context = canvas.getContext('2d');
    context.drawImage(frame, 0, 0);
    const gold = context.createLinearGradient(360, 53, 703, 218);
    [[0, '#f5dfaa'], [.31, '#e4be79'], [.65, '#a7773c'], [.84, '#dcb170'], [1, '#ad793f']]
      .forEach(([at, color]) => gold.addColorStop(at, color));
    const nameSize = name.length > 4 ? 132 : name.length > 3 ? 148 : 172;
    centeredLine(context, name, 1716, 'ShotName', nameSize, 25, 896, '#070606');
    centeredLine(context, name, 1712, 'ShotName', nameSize, 25, 896, gold, true);
    centeredLine(context, date, 1781, 'ShotDate', 39, 3, 220, '#e1c89b');
    centeredLine(context, event, 1863, 'ShotEvent, ShotDate', 60, 10, 924, '#f0e5d1');
    return canvas;
  }

  function save(blob, filename) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  function action(group, feedback, title, run) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'shot-material';
    button.textContent = title;
    button.addEventListener('click', async () => {
      if (button.getAttribute('aria-disabled') === 'true') return;
      button.setAttribute('aria-disabled', 'true');
      feedback.textContent = '正在準備下載…';
      try {
        await run();
        feedback.textContent = '已送出下載。';
      } catch {
        feedback.textContent = '下載失敗，請再試一次。';
      } finally {
        button.removeAttribute('aria-disabled');
      }
    });
    group.append(button);
  }

  function toBlob(canvas, type) {
    return new Promise((resolve, reject) => canvas.toBlob(blob => {
      if (blob) resolve(blob);
      else reject(new Error('Image encoding failed'));
    }, type, .94));
  }

  function stillBlock(shot, source) {
    return Array.from(shot.querySelectorAll('img[src]')).find(image =>
      new URL(image.getAttribute('src'), location.href).href === new URL(source, location.href).href
    );
  }

  function mount(shot, name, [date, event, source], exportedName, observer) {
    const image = stillBlock(shot, source);
    if (!image) return;
    const figure = image.closest('figure');
    const original = image.parentElement.tagName === 'A' ? image.parentElement : image;
    const outer = original.closest('.story-shot-card, .yam-shot-card') || figure || original.parentElement;
    const earlierTitle = outer.querySelector(oldLabel);
    const preview = document.createElement('div');
    preview.className = 'shot-title-preview';
    original.before(preview);
    preview.append(original);

    const panel = canvasOf(height - titleTop);
    panel.className = 'fixed-shot-title';
    panel.setAttribute('role', 'img');
    panel.setAttribute('aria-label', `${name}，${date}，${event}`);
    let painting;
    const render = () => {
      painting ??= paintTitle(panel, name, date, event).then(result => {
        earlierTitle?.remove();
        preview.append(result);
        return result;
      }).catch(error => {
        painting = undefined;
        throw error;
      });
      return painting;
    };

    const download = document.createElement('div');
    download.className = 'shot-materials';
    const feedback = document.createElement('output');
    feedback.className = 'shot-material-feedback';
    feedback.setAttribute('aria-live', 'polite');
    const originalUrl = new URL(source, location.href);
    const extension = originalUrl.pathname.split('.').pop();
    if (originalUrl.origin === location.origin) {
      const link = document.createElement('a');
      link.className = 'shot-material';
      link.textContent = '動畫底圖';
      link.href = source;
      link.download = `${exportedName}-seedance.${extension}`;
      download.append(link);
    } else {
      action(download, feedback, '動畫底圖', async () => {
        const response = await fetch(source);
        if (!response.ok) throw new Error('Original image unavailable');
        save(await response.blob(), `${exportedName}-seedance.${extension}`);
      });
    }
    action(download, feedback, '固定字卡 PNG', async () => {
      const layer = canvasOf(height);
      layer.getContext('2d').drawImage(await render(), 0, titleTop);
      save(await toBlob(layer, 'image/png'), `${exportedName}-title.png`);
    });
    action(download, feedback, '含字卡主分鏡', async () => {
      const [picture, title] = await Promise.all([loadImage(source), render()]);
      const result = canvasOf(height);
      const context = result.getContext('2d');
      const scale = Math.min(width / picture.naturalWidth, height / picture.naturalHeight);
      const w = scale * picture.naturalWidth, h = scale * picture.naturalHeight;
      context.fillStyle = '#080909';
      context.fillRect(0, 0, width, height);
      context.drawImage(picture, (width - w) / 2, (height - h) / 2, w, h);
      context.drawImage(title, 0, titleTop);
      save(await toBlob(result, 'image/jpeg'), `${exportedName}-storyboard.jpg`);
    });
    download.append(feedback);
    const caption = figure?.querySelector('figcaption:not(.story-shot-title):not(.yam-shot-label)');
    if (figure) (caption || figure).append(download);
    else outer.after(download);

    // Remove duplicate original download links while retaining board and reference downloads.
    for (const link of shot.querySelectorAll('a[download]')) {
      if (download.contains(link)) continue;
      const href = link.getAttribute('href');
      const sameImage = href && new URL(href, location.href).href === originalUrl.href;
      if (sameImage || (figure?.contains(link) && !href) ||
          (figure?.contains(link) && href === '#' && link.hasAttribute('data-board')) ||
          (figure?.contains(link) && link.hasAttribute('data-href-key'))) link.remove();
    }
    if (observer) {
      preview.renderShotTitle = render;
      observer.observe(preview);
    } else render().catch(() => {});
  }

  async function initialize() {
    const response = await fetch(directory + 'scenes.json');
    if (!response.ok) return;
    const route = location.pathname.replace(/index\.html$/, '').replace(/\/?$/, '/');
    const scene = (await response.json())[route];
    if (!scene) return;
    const [name, shots] = scene;
    const observer = typeof IntersectionObserver === 'function' ? new IntersectionObserver(entries => {
      for (const {target, isIntersecting} of entries) {
        if (!isIntersecting) continue;
        observer.unobserve(target);
        target.renderShotTitle().catch(() => {});
      }
    }, {rootMargin: '550px'}) : null;
    const materialHint = document.createElement('p');
    materialHint.className = 'shot-material-hint';
    materialHint.textContent = '動畫底圖給 Seedance。影片生成後，在 CapCut 上層疊同鏡的固定字卡 PNG，運鏡套用在影片軌。';
    const first = document.getElementById(Object.keys(shots)[0]);
    first?.before(materialHint);
    for (const [id, data] of Object.entries(shots)) {
      const shot = document.getElementById(id);
      if (shot) mount(shot, name, data, `${name}-${route.includes('/battle/') ? '戰鬥版-' : ''}${id.match(/\d+$/)[0]}`, observer);
    }
  }

  initialize().catch(error => console.error('Shot title cards unavailable', error));
})();
