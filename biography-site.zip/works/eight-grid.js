(() => {
  const format = (n) => n.toFixed(2).replace(/\.?0+$/, '');
  const sourceImages = new Map();
  let stopPreview = () => {};
  for (const board of document.querySelectorAll('.eight-shot')) {
    const frames = [...board.querySelectorAll('.eight-frames li')];
    const button = board.querySelector('[data-eight-play]');
    const output = board.querySelector('output');
    const duration = Number(board.dataset.duration);
    const section = board.closest('article, section');
    const source = section.querySelector('img:not(.eight-shot img)');
    if (source) sourceImages.set(board, source);
    const setFrame = (index) => {
      frames.forEach((frame, i) => frame.toggleAttribute('data-active', i === index));
    };
    const load = () => {
      if (!board.open || board.dataset.loaded) return;
      const art = sourceImages.get(board);
      for (const frame of frames) {
        const image = frame.querySelector('.eight-crop img');
        if (image && !image.hasAttribute('src') && art) image.src = art.currentSrc || art.src;
      }
      board.dataset.loaded = '1';
    };
    load();
    board.addEventListener('toggle', () => {
      load();
      if (!board.open && button.dataset.playing) stopPreview();
    });
    button.addEventListener('click', () => {
      const wasPlaying = Boolean(button.dataset.playing);
      stopPreview();
      if (wasPlaying) return;
      const start = performance.now();
      button.dataset.playing = '1';
      button.textContent = '停止預演';
      setFrame(0);
      const tick = () => {
        const elapsed = (performance.now() - start) / 1000;
        if (elapsed >= duration) {
          stopPreview();
          setFrame(-1);
          output.textContent = '已播完 ' + duration + ' 秒';
          return;
        }
        const frame = Math.min(7, Math.floor(elapsed * 8 / duration));
        setFrame(frame);
        output.textContent = '第 ' + (frame + 1) + ' 格 · ' + format(duration * frame / 8) + ' 秒';
      };
      tick();
      const timer = setInterval(tick, 40);
      stopPreview = () => {
        clearInterval(timer);
        delete button.dataset.playing;
        setFrame(-1);
        button.textContent = '預演 ' + duration + ' 秒節奏';
        output.textContent = '就緒';
      };
    });
  }

  for (const button of document.querySelectorAll('[data-eight-copy]')) {
    button.addEventListener('click', async () => {
      const target = button.dataset.eightCopy;
      const fields = [...document.querySelectorAll(target)];
      const text = fields.map(field => field.value).join('\n\n');
      const status = button.closest('.eight-buttons').querySelector('output');
      let copied = false;
      try {
        await navigator.clipboard.writeText(text);
        copied = true;
      } catch {
        const selection = document.createElement('textarea');
        selection.value = text;
        selection.style.cssText = 'position:fixed;left:0;top:0;opacity:0;';
        document.body.append(selection);
        selection.select();
        try { copied = document.execCommand('copy'); } catch {}
        selection.remove();
        button.focus();
      }
      status.textContent = copied ? '已複製全文 ✓' : '複製未成功，可選取文字區全文';
    });
  }
})();
